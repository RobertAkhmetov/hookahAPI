﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Models;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;
using Newtonsoft.Json;


namespace WebApplication2.Models
{
    public class ComplaintContext : DbContext
    {
        public DbSet<Complaint> complaints { get; set; }

        public ComplaintContext()
        {
            Database.EnsureCreated();
        }

        public ComplaintContext(DbContextOptions<ComplaintContext> options) : base(options)
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql("Host=localhost;Port=5432;Database=usersdb;Username=usersdb;Password='postgres'");
        }
    }


    public class Complaint
    {
        [JsonIgnore]
        public int id { get; set; }

        [Column("idreview")]
        public int idReview;
        public string complaint;
        [Column("iduser")]
        public int idUser;
        public string contact;
        public bool active;
        [Column("datecreate")]
        public string dateCreate;

    }
}
