﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


using Microsoft.EntityFrameworkCore; // Entity Framework Core
using WebApplication2.Models;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication2.Models
{
    public class HookaContext : DbContext
    {
        public DbSet<Hooka> hookas { get; set; }

        public HookaContext()
        {
            Database.EnsureCreated();
        }

        public HookaContext(DbContextOptions<HookaContext> options) : base(options)
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql("Host=localhost;Port=5432;Database=usersdb;Username=postgres;Password='postgres'");
        }

        public DbSet<WebApplication2.Models.User> User { get; set; }
    }

    public class Hooka
    {
        public int id { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public int price { get; set; }
        public double lat { get; set; }
        public double lon { get; set; }
        public string adress { get; set; }

        [Column("workweek")]
        public string workWeek { get; set; }

        [Column("worktimestart")]
        public string workTimeStart { get; set; }

        [Column("worktimeend")]
        public string workTimeEnd { get; set; }

        /*public Dictionary<string, string> social = new Dictionary<string, string>
        {
            {"instagram","value2" },
            {"ok","value1" },
            {"tiktok","value1" },
            {"facebook","value1" },
            {"telegtam","value1" },
            {"site","value1" },
        };*/

        public string social { get; set; }

        public double rating { get; set; }

        [Column("ratingcount")]
        public int ratingCount { get; set; }
        public string city { get; set; }

        [Column("iswork")]
        public bool isWork { get; set; }
        public bool active { get; set; }
        public string phone { get; set; }

        [Column("datecreate")]
        public string dateCreate { get; set; }

        [Column("dateupdate")]
        public string dateUpdate { get; set; }

        public string compliments { get; set; }
        public int owner { get; set; }
        public string banner { get; set; }
        public List<string> menu { get; set; }

        /*
        public Dictionary<string,int> Prices= new Dictionary<string, int>
        {
            {"hookah",0}
        };
        */

    }



    public class HookaForMap
    {
        public int id { get; set; }
        public string title { get; set; }
        public double lat { get; set; }
        public double lon { get; set; }
        public double rating { get; set; }

    }

    public class HookaForPopular
    {
        public int id { get; set; }
        public string title { get; set; }
        public string banner { get; set; }
        public double lat { get; set; }
        public double lon { get; set; }
        public double rating { get; set; }

    }

    public class HookaForNearby
    {
        public int id { get; set; }
        public string title { get; set; }
        public string banner { get; set; }
        public double lat { get; set; }
        public double lon { get; set; }
        public double rating { get; set; }
        public string adress { get; set; }
        public int price { get; set; }

    }

}
