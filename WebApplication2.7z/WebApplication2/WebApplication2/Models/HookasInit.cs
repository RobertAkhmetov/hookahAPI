﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{
    public class hookasInit
    {
        public static void Initialize(HookaContext context)
        {
            //if (!context.hookas.Any()) //если это поле не использовать,
            //в конец БД в любом случае добавятся кальянные ниже
            {
                // добавляем кальянную в бд
                context.hookas.AddRange(
                     new Hooka
                     {
                         title = "Panda",
                         price = 2400,
                     //Prices = new Dictionary<string, int> { { "hookah1", 950 } },
                     lat = 20,
                         lon = 40,
                     },

                     new Hooka
                     {
                         title = "Дымный дым",
                     //Prices = new Dictionary<string, int>{ { "hookah", 100 } },
                 }
                    );

                // сохраняем в базу данных
                context.SaveChanges();
            }
        }
    }
}
