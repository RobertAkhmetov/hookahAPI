﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore; // Entity Framework Core
using WebApplication2.Models;
using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApplication2.Models
{
    public class UserContext : DbContext
    {
        public DbSet<WebApplication2.Models.User> users { get; set; }

        public UserContext()
        {
            Database.EnsureCreated();
        }

        
        public UserContext(DbContextOptions<UserContext> options) : base(options)
        {
            Database.EnsureCreated();
        }
        

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql("Host=localhost;Port=5432;Database=usersdb;Username=usersdb;Password='postgres'");
        }


    }

    public class User
    {
        public int id { get; set; }

        [Column("user_name")]
        public string name { get; set; }

        [Column("user_email")]
        public string email { get; set; }

        [JsonIgnore]
        public string user_password_hash { get; set; }
    }
}
