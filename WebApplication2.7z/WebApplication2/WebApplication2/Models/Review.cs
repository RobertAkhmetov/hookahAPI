﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Models;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;
using Newtonsoft.Json;

namespace WebApplication2.Models
{
    public class ReviewContext : DbContext
    {
        public DbSet<WebApplication2.Models.Review> reviews { get; set; }

        public ReviewContext()
        {
            Database.EnsureCreated();
        }

        public ReviewContext(DbContextOptions<ReviewContext> options) : base(options)
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql("Host=localhost;Port=5432;Database=usersdb;Username=usersdb;Password='postgres'");
        }
    }

    public class Review
    {
        [JsonIgnore]
        public int id { get; set; }

        [Column("idhookah")]
        public int idHookah { get; set; }

        [Column("iduser")]
        public int idUser { get; set; }
        public string comment { get; set; }
        //public int [] compliments { get; set; }
        public string compliments { get; set; }
        public int rating { get; set; }

        [Column("datecreate")]
        public string dateCreate { get; set; }
        public bool active { get; set; }
    }

    public class ReviewForUserReviewList
    {
        public int id { get; set; }

        //[Column("idhookah")]
        public int idHookah { get; set; }
        public string comment { get; set; }
        //public string compliments { get; set; }
        public int rating { get; set; }

        //[Column("datecreate")]
        public string dateCreate { get; set; }
    }

    public class ReviewForHookahReviewList
    {
        public int id { get; set; }
        public int idUser { get; set; }
        public string comment { get; set; }
        public int rating { get; set; }
        public string dateCreate { get; set; }
    }
}
